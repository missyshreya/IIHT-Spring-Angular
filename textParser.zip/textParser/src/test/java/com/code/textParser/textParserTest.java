package com.code.textParser;



import static org.junit.Assert.assertEquals;

import java.util.LinkedHashMap;

import org.junit.Test;




public class textParserTest {

	@Test
	public void test() {
		String input = "This problem is simple. Simple problems need attention.";
		TextParser t = new TextParser();		
		LinkedHashMap<String, Integer> expected= new LinkedHashMap<>();
		expected.put("this", 1);
		expected.put("problem", 1);
		expected.put("is", 1);
		expected.put("simple", 2);
		expected.put("problems", 1);
		expected.put("need", 1);
		expected.put("attention", 1);

		LinkedHashMap<String, Integer> actual = t.wordsCount(input);
		
		assertEquals(expected, actual);
		
	}

}
