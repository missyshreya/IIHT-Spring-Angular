package com.code.textParser;

public class ParserMain {

	public static void main(String[] args) {
		String input = "This problem is simple. Simple problems need attention.";
		TextParser t = new TextParser();
		System.out.println(t.wordsCount(input));

	}

}
